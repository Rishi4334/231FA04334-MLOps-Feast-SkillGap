# CSE Employability Skill-Gap MLOps Project

## Problem
Curriculum-Industry Skill Alignment Decision Framework for Identifying Employability Skill Gaps in CSE Graduates.

## ML target
`Skill_Gap_Level`

## Selected model
`Gradient Boosting`

## Pipeline
Dataset -> Preprocessing -> ML Training -> Evaluation -> FastAPI -> pytest -> Docker -> GitHub Actions CI/CD

## API
Run `pip install -r requirements.txt` and then `uvicorn app.main:app --host 0.0.0.0 --port 8000`.

## CI/CD
Tests run first. The Docker/CD job uses `needs: test`, so it only runs after CI succeeds.
