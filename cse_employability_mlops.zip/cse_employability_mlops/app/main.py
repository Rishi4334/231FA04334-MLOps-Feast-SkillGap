from fastapi import FastAPI
from pydantic import BaseModel, Field
import pandas as pd
import joblib
import os

MODEL_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'models', 'employability_model.joblib')
model = joblib.load(MODEL_PATH)

app = FastAPI(title='CSE Employability Skill-Gap API', version='1.0.0')

class StudentInput(BaseModel):
    data: dict = Field(..., description='Feature values using training feature names')

@app.get('/')
def root():
    return {'message': 'CSE Employability Skill-Gap API is running', 'target': 'Skill_Gap_Level', 'model': 'Gradient Boosting'}

@app.get('/health')
def health():
    return {'status': 'healthy'}

@app.post('/predict')
def predict(student: StudentInput):
    row = pd.DataFrame([student.data])
    missing = [c for c in model.feature_names_in_ if c not in row.columns]
    if missing:
        return {'error': 'Missing required features', 'missing_features': missing}
    row = row[model.feature_names_in_]
    prediction = model.predict(row)[0]
    response = {'prediction': str(prediction), 'target': 'Skill_Gap_Level'}
    if hasattr(model, 'predict_proba'):
        probabilities = model.predict_proba(row)[0]
        response['probabilities'] = {str(c): float(p) for c, p in zip(model.classes_, probabilities)}
    return response
