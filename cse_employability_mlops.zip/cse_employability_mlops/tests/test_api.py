import os, sys
from fastapi.testclient import TestClient
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from app.main import app

client = TestClient(app)

def test_health():
    response = client.get('/health')
    assert response.status_code == 200
    assert response.json()['status'] == 'healthy'

def test_root():
    response = client.get('/')
    assert response.status_code == 200
    assert 'target' in response.json()

def test_prediction():
    sample = '{"Age": 20, "Gender": "Male", "Degree": "B.Tech", "Specialization": "Cyber Security", "Current_Year": 2, "Semester": 4, "CGPA": 8.65, "Attendance_Percentage": 89, "Internal_Marks": 52, "External_Marks": 69, "Mini_Project_Score": 44, "Major_Project_Score": 59, "Lab_Performance": 63, "Assignment_Average": 65, "Backlogs": 3, "Academic_Consistency": 58, "Class_Rank": 182, "C_Programming": 4, "C++_Programming": 5, "Java": 3, "Python": 4, "JavaScript": 6, "SQL": 5, "HTML_CSS": 5, "ReactJS": 5, "NodeJS": 5, "Programming_Logic": 6, "Arrays": 8, "Linked_Lists": 5, "Stacks_Queues": 6, "Trees": 4, "Graphs": 6, "Dynamic_Programming": 6, "Searching_Sorting": 6, "Competitive_Coding": 5, "Statistics": 6, "Linear_Algebra": 3, "Machine_Learning": 7, "Deep_Learning": 7, "NLP": 6, "Computer_Vision": 5, "Data_Preprocessing": 5, "Feature_Engineering": 5, "Model_Evaluation": 10, "Data_Visualization": 5, "AWS": 7, "Azure": 6, "Google_Cloud": 3, "Docker": 6, "Kubernetes": 5, "MLflow": 6, "DVC": 3, "FastAPI": 5, "CI_CD": 6, "Model_Monitoring": 7, "MySQL": 5, "PostgreSQL": 3, "MongoDB": 4, "Firebase": 4, "REST_API": 5, "Spring_Boot": 8, "ExpressJS": 3, "API_Development": 4, "Git": 7, "GitHub": 7, "Agile": 4, "Jira": 3, "Linux": 5, "VSCode_Productivity": 4, "Computer_Networks": 5, "Operating_Systems": 3, "Cybersecurity": 4, "Network_Security": 5, "Ethical_Hacking": 1, "Linux_Administration": 7, "Communication": 7, "Teamwork": 7, "Leadership": 5, "Problem_Solving": 5, "Critical_Thinking": 2, "Time_Management": 5, "Adaptability": 6, "Creativity": 7, "Presentation_Skills": 6, "English_Proficiency": 2, "Internship_Count": 3, "Internship_Duration_Months": 3, "Projects_Completed": 7, "Open_Source_Contributions": 17, "GitHub_Repositories": 12, "LeetCode_Problems_Solved": 26, "HackerRank_Badge_Level": "Silver", "Certifications": 8, "Hackathons_Attended": 7, "Resume_Score": 76, "Aptitude_Score": 95, "Technical_Interview_Score": 58, "HR_Interview_Score": 49, "Mock_Interview_Score": 52}'
    import json
    sample = json.loads(sample)
    response = client.post('/predict', json={'data': sample})
    assert response.status_code == 200
    body = response.json()
    assert 'prediction' in body
    assert 'target' in body
